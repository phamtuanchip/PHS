Phan mem quan ly kach san
phien ban 1.0 RC



