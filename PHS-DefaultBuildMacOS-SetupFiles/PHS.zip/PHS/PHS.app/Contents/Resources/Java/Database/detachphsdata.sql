
use master
EXEC sp_detach_db 'phs_data', 'true'